from django.apps import AppConfig


class RagavendraStoreConfig(AppConfig):
    name = 'ragavendra_store'
